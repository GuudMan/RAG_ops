# from IPython.display import display, HTML
# import pandas as pd

# data = {'Name': ['Alice', 'Bob', 'Charlie'],
#         'Age': [25, 30, 35],
#         'City': ['New York', 'Los Angeles', 'Chicago']}
# df = pd.DataFrame(data)
# display(HTML(df.to_html()))
from rich import print

print("有些人， 走着走着就散了！")