from llama_index.core import (
    StorageContext,
    VectorStoreIndex,
    SimpleDirectoryReader,
    ServiceContext,
    load_index_from_storage
)
from llama_index.core.node_parser import SimpleNodeParser
from llama_index.core.query_engine import RetrieverQueryEngine
from llama_index.embeddings.huggingface import HuggingFaceEmbedding
from llama_index.llms.huggingface import HuggingFaceLLM
from llama_index.core import (VectorStoreIndex, 
                              SimpleDirectoryReader,
                              ServiceContext,
                              StorageContext, 
                              load_index_from_storage
                              )
from llama_index.core.node_parser import SimpleNodeParser
from llama_index.core.query_engine import RetrieverQueryEngine

from trulens_eval import Feedback, Tru, TruLlama
from trulens_eval.feedback import Groundedness
from trulens_eval.feedback import GroundTruthAgreement
from trulens_eval.feedback.provider.openai import OpenAI as OpenAITruLens

import numpy as np
import os
os.environ['CUDA_VISIBLE_DEVICES'] = "2, 3"

def completion_to_prompt(completion):
   return f"<|im_start|>system\n<|im_end|>\n<|im_start|>user\n{completion}<|im_end|>\n<|im_start|>assistant\n"

def messages_to_prompt(messages):
    prompt = ""
    for message in messages:
        if message.role == "system":
            prompt += f"<|im_start|>system\n{message.content}<|im_end|>\n"
        elif message.role == "user":
            prompt += f"<|im_start|>user\n{message.content}<|im_end|>\n"
        elif message.role == "assistant":
            prompt += f"<|im_start|>assistant\n{message.content}<|im_end|>\n"

    if not prompt.startswith("<|im_start|>system"):
        prompt = "<|im_start|>system\n" + prompt

    prompt = prompt + "<|im_start|>assistant\n"

    return prompt

llm = HuggingFaceLLM(
    model_name="../model_local/qwen/Qwen1.5-7B-Chat",
    tokenizer_name="../model_local/qwen/Qwen1.5-7B-Chat",
    context_window=30000, 
    max_new_tokens=2000,
    generate_kwargs={"temperature": 0.7, 
                     "top_k": 50, 
                     "top_p": 0.95},
    messages_to_prompt=messages_to_prompt,
    completion_to_prompt=completion_to_prompt,
    device_map="auto"
    )

embedding_model = "../embedding_model"
embed_model = HuggingFaceEmbedding(
    model_name = embedding_model
)

service_context = ServiceContext.from_defaults(
    embed_model=embed_model, 
    llm=llm
)

# check if data indexes already exists
if not os.path.exists("./data_base/llama_rag_9"):
    # load data
    documents = SimpleDirectoryReader(
        input_dir="../ops_txt_temp").load_data(show_progress=True)

    # create nodes parser
    node_parser = SimpleNodeParser.from_defaults(chunk_size=1024)

    # split into nodes
    base_nodes = node_parser.get_nodes_from_documents(documents=documents)

    # creating index
    index = VectorStoreIndex(nodes=base_nodes, service_context=service_context)

    # store index
    index.storage_context.persist()
else:
    # load existing index
    storage_context = StorageContext.from_defaults(persist_dir="./data_base/llama_rag_9")
    index = load_index_from_storage(storage_context=storage_context)


# create retriever
retriever = index.as_retriever(similarity_top_k=2)
query = "ZXUN uMAC系统为什么采用服务化架构"

# query retriever engine
query_engine = RetrieverQueryEngine.from_args(
    retriever=retriever,
    service_context=service_context
)

# RAG pipeline evals
tru = Tru()

openai = OpenAITruLens()

grounded = Groundedness(groundedness_provider=OpenAITruLens())

# Define a groundedness feedback function
f_groundedness = Feedback(grounded.groundedness_measure_with_cot_reasons).on(
    TruLlama.select_source_nodes().node.text
    ).on_output(
    ).aggregate(grounded.grounded_statements_aggregator)

# Question/answer relevance between overall question and answer.
f_qa_relevance = Feedback(openai.relevance).on_input_output()

# Question/statement relevance between question and each context chunk.
f_qs_relevance = Feedback(openai.qs_relevance).on_input().on(
    TruLlama.select_source_nodes().node.text
    ).aggregate(np.mean)


tru_query_engine_recorder = TruLlama(query_engine,
    app_id='LlamaIndex_App1',
    feedbacks=[f_groundedness, f_qa_relevance, f_qs_relevance])


# eval using context window
with tru_query_engine_recorder as recording:
    query_engine.query(query)


# run dashboard
tru.run_dashboard()