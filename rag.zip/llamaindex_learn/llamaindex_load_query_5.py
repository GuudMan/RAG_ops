"""
在RAG检索和生成这样的框架内管理和处理多个文档有很大的挑战
关键不仅在于提取相关内容， 还在于选择包含用户查询所寻求的信息和适当文档。
基于用户查询对齐的多粒度特性， 需要动态选择文档。
llamaindex支持多层次信息检索， 它不只是筛选文档， 而是利用元数据过滤来
简化选择过程。通过使用自动检索机制， 这些过滤器可以根据用户查询检索出最
相关的文档。这些过程包括推断语义查询，在矢量数据库中确定最佳过滤器集，
有效地将文本到SQL和语义搜索的能力结合起来。

结构化层次检索的优点。
1、增强相关性：通过利用元数据驱动的过滤器，可以准确地识别和检索符合
用户查询细微要求的文档。这确保了内容选择中更高的相关性和准确性。
2、动态选择文档：与传统的静态文档检索不同， llamaindex支持动态文档选择。
llamaindex通过根据相关文档的属性和结构化元数据灵活选择相关文档，
智能地适应不同的用户查询。
3、高效信息检索。结构化层次检索显著提高了信息检索的效率。通过将文档预处理到元数据
字典中并将其存储在矢量数据库中， 该系统简化了检索过程， 最大限度地减少了计算开销
并优化了搜索效率。
4、语义查询优化。文本到sql和语义搜索的融合使系统能更好地理解用户意图，
llamaindex自动检索机制将用户查询细化为语义结构，从而能够从文档存储库中
精准而细致地检索信息。

三、结构化层次检索代码
文档添加：add_document方法通过创建包含摘要和关键字等关键信息的元数据字典。
将文档添加到llamaindex
检索逻辑：retrieve_documents方法将用户查询与矢量数据库的元数据过滤器进行匹配来处理用
户查询。
匹配机制： match_metadata方法模拟用户查询和文档元数据之间的匹配过程。
"""
import os
import logging
import sys
from llama_index.core.callbacks import (
    CallbackManager
)
from llama_index.core import (SimpleDirectoryReader, 
                              ServiceContext,
                              VectorStoreIndex, 
                              )
from llama_index.core.retrievers import (VectorIndexRetriever, 
                                         BaseRetriever)


from llama_index.llms.huggingface import HuggingFaceLLM
from llama_index.core.schema import (QueryBundle, 
                                     QueryType,
                                     NodeWithScore)
from typing import List
from llama_index.core.postprocessor import SentenceTransformerRerank
from llama_index.callbacks.wandb import WandbCallbackHandler
from llama_index.core import load_index_from_storage
from llama_index.core.query_engine import PandasQueryEngine
from llama_index.core import (
  VectorStoreIndex, 
  SimpleKeywordTableIndex, 
  SimpleDirectoryReader, 
  StorageContext,
  ServiceContext
 )
from llama_index.embeddings.huggingface import HuggingFaceEmbedding
import os
os.environ['CUDA_VISIBLE_DEVICES'] = "0, 1"


def completion_to_prompt(completion):
   return f"<|im_start|>system\n<|im_end|>\n<|im_start|>user\n{completion}<|im_end|>\n<|im_start|>assistant\n"

def messages_to_prompt(messages):
    prompt = ""
    for message in messages:
        if message.role == "system":
            prompt += f"<|im_start|>system\n{message.content}<|im_end|>\n"
        elif message.role == "user":
            prompt += f"<|im_start|>user\n{message.content}<|im_end|>\n"
        elif message.role == "assistant":
            prompt += f"<|im_start|>assistant\n{message.content}<|im_end|>\n"

    if not prompt.startswith("<|im_start|>system"):
        prompt = "<|im_start|>system\n" + prompt

    prompt = prompt + "<|im_start|>assistant\n"

    return prompt



llm = HuggingFaceLLM(
    model_name="../model_local/qwen/Qwen1.5-7B-Chat",
    tokenizer_name="../model_local/qwen/Qwen1.5-7B-Chat",
    context_window=30000, 
    max_new_tokens=2000,
    generate_kwargs={"temperature": 0.7, 
                     "top_k": 50, 
                     "top_p": 0.95},
    messages_to_prompt=messages_to_prompt,
    completion_to_prompt=completion_to_prompt,
    device_map="auto"
    )

embedding_model = "../embedding_model"
embed_model = HuggingFaceEmbedding(
    model_name = embedding_model
)


wandb_args = {"project": "llama-index-report"}
wandb_callback = WandbCallbackHandler(run_args=wandb_args)
callback_manager = CallbackManager([wandb_callback])
service_context = ServiceContext.from_defaults(llm=llm, embed_model=embed_model)

from llama_hub.github_repo_issues import (
    GitHubRepositoryIssuesReader,
    GitHubIssuesClient
)

github_client = GitHubIssuesClient()
loader = GitHubRepositoryIssuesReader(
    github_client, 
    owner="run-llama",
    repo="llama_index",
    verbose=True,
)

orig_docs = loader.load_data()
limit = 100
docs = []
for idx, doc in enumerate(orig_docs):
    doc.metadata["index_id"] = doc.id_
    if idx >= limit:
        break
    docs.append(doc)
    






























