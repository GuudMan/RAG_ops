"""
llama_index实现多模态rag
"""
from bs4 import BeautifulSoup
import os
from bs4 import BeautifulSoup, NavigableString
from llama_index.core.indices.multi_modal.base import MultiModalVectorStoreIndex
# from llama_index.vector_stores.neo4jvector import Neo4jVectorStore
from llama_index.vector_stores.neo4jvector import Neo4jVectorStore
from llama_index.core import (StorageContext, Document, Settings)
from llama_index.core.schema import ImageDocument
from llama_index.core.node_parser import SimpleNodeParser
from llama_index.multi_modal_llms.openai import OpenAIMultiModal
from llama_index.embeddings.huggingface import HuggingFaceEmbedding
from llama_index.multi_modal_llms.ollama import OllamaMultiModal
import tiktoken
# import seaborn as sns
import requests
from PIL import Image
# import matplotlib.pyplot as plt
from io import BytesIO

##设置embeding 模型和llva模型
Settings.embed_model = HuggingFaceEmbedding(model_name="../model_local/BAAI/bge-small-en-v1.5")
mm_model = OllamaMultiModal(model="llava")


def process_html_file(file_path):
    with open(file_path, "r", encoding="utf-8") as file:
        soup = BeautifulSoup(file, "html.parser")

    # Find the required section
    content_section = soup.find("section", {"data-field": "body", "class": "e-content"})

    if not content_section:
        return "Section not found."

    sections = []
    current_section = {"header": "", "content": "", "source": file_path.split("/")[-1]}
    images = []
    header_found = False

    for element in content_section.find_all(recursive=True):
        if element.name in ["h1", "h2", "h3", "h4"]:
            if header_found and (current_section["content"].strip()):
                sections.append(current_section)
            current_section = {
                "header": element.get_text(),
                "content": "",
                "source": file_path.split("/")[-1],
            }
            header_found = True
        elif header_found:
            if element.name == "pre":
                current_section["content"] += f"```{element.get_text().strip()}```\n"
            elif element.name == "img":
                img_src = element.get("src")
                img_caption = element.find_next("figcaption")
                caption_text = img_caption.get_text().strip() if img_caption else ""
                images.append(ImageDocument(image_url=img_src))
            elif element.name in ["p", "span", "a"]:
                current_section["content"] += element.get_text().strip() + "\n"

    if current_section["content"].strip():
        sections.append(current_section)

    return images, sections


all_documents = []
all_images = []

# Directory to search in (current working directory)
directory = os.getcwd()

# Walking through the directory
for root, dirs, files in os.walk(os.path.join(directory, "article")):
    for file in files:
        if file.endswith(".html"):
            # Update the file path to be relative to the current directory
            images, documents = process_html_file(os.path.join(root, file))
            all_documents.extend(documents)
            all_images.extend(images)

text_docs = [Document(text=el.pop("content"), metadata=el) for el in all_documents]
print(f"Text document count: {len(text_docs)}")
print(f"Image document count: {len(all_images)}")
print(all_images[0])

# Indexing data vectors
print("=" * 10 +"Indexing data vectors"+ "=" * 10)

NEO4J_URI="neo4j://172.17.1.189:7687"
NEO4J_USERNAME="neo4j"
NEO4J_PASSWORD="neo4j"

text_store = Neo4jVectorStore(
    url=NEO4J_URI,
    username=NEO4J_USERNAME,
    password=NEO4J_PASSWORD,
    index_name="text_collection",
    node_label="Chunk",
    embedding_dimension=1536
)
image_store = Neo4jVectorStore(
    url=NEO4J_URI,
    username=NEO4J_USERNAME,
    password=NEO4J_PASSWORD,
    index_name="image_collection",
    node_label="Image",
    embedding_dimension=512
)

storage_context = StorageContext.from_defaults(vector_store=text_store)

# Takes 10 min without GPU / 1 min with GPU on Google collab
index = MultiModalVectorStoreIndex.from_documents(
    text_docs + all_images, storage_context=storage_context, image_vector_store=image_store
)

from llama_index.core.prompts import PromptTemplate
from llama_index.core.query_engine import SimpleMultiModalQueryEngine

# openai_mm_llm = OpenAIMultiModal(
#     model="gpt-4-vision-preview", max_new_tokens=1500
# )
