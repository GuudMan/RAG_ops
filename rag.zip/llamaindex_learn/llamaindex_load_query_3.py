"""
高级RAG 02：选择最佳embedding和重排序模型
"""
from llama_index.core import (SimpleDirectoryReader, 
                              ServiceContext,
                              VectorStoreIndex, 
                              )
from llama_index.core.retrievers import (VectorIndexRetriever, 
                                         BaseRetriever)

from llama_index.core.node_parser import (SimpleNodeParser,
                                          )

from llama_index.llms.huggingface import HuggingFaceLLM
from llama_index.embeddings.huggingface import HuggingFaceEmbedding
from llama_index.core.postprocessor import MetadataReplacementPostProcessor
from llama_index.core.evaluation import (generate_question_context_pairs, 
                                         EmbeddingQAFinetuneDataset)
from llama_index.core.schema import (QueryBundle, 
                                     QueryType,
                                     NodeWithScore)
from typing import List
from llama_index.core.postprocessor import SentenceTransformerRerank

import os
os.environ['CUDA_VISIBLE_DEVICES'] = "0, 1"

def completion_to_prompt(completion):
   return f"<|im_start|>system\n<|im_end|>\n<|im_start|>user\n{completion}<|im_end|>\n<|im_start|>assistant\n"

def messages_to_prompt(messages):
    prompt = ""
    for message in messages:
        if message.role == "system":
            prompt += f"<|im_start|>system\n{message.content}<|im_end|>\n"
        elif message.role == "user":
            prompt += f"<|im_start|>user\n{message.content}<|im_end|>\n"
        elif message.role == "assistant":
            prompt += f"<|im_start|>assistant\n{message.content}<|im_end|>\n"

    if not prompt.startswith("<|im_start|>system"):
        prompt = "<|im_start|>system\n" + prompt

    prompt = prompt + "<|im_start|>assistant\n"

    return prompt


print("=" * 10 +"加载数据"+ "=" * 10)
"""
加载数据。将这些数据转换为节点进行解析， 这些节点表示我们想要检索的数据块，
设置chunk_size为512
"""
documents = SimpleDirectoryReader(input_dir="../test_data").load_data()

node_parser = SimpleNodeParser.from_defaults(chunk_size=512)
nodes = node_parser.get_nodes_from_documents(documents)

print("=" * 10 + "生成问题上下文对" + "=" * 10)
"""
为了评估， 创建了一个问题上下文对数据集， 该数据集包含一些列
问题以及相应的上下文。为了消除embedding和重排序评估的偏差， 
使用llm生成问题上下文对
初始化一个Prompt模版生成问题上下文对
"""
# Prompt to generate questions
qa_generate_prompt_tmpl = """\
上下文信息如下。
---------------------
{context_str}
---------------------
给定上下文信息，不给定先验知识， 仅根据以下查询生成问题。
你是一位教授。你的任务是为即将到来的测验/考试设置 \
{num_questions_per_chunk}. 这些问题应该在整个文档中具有多样性.问题不应该包含选项，\
不应该以Q1/Q2开头。问题限制在所提供的上下文信息中。
"""


llm = HuggingFaceLLM(
    model_name="../model_local/qwen/Qwen1.5-7B-Chat",
    tokenizer_name="../model_local/qwen/Qwen1.5-7B-Chat",
    context_window=30000, 
    max_new_tokens=2000,
    generate_kwargs={"temperature": 0.7, 
                     "top_k": 50, 
                     "top_p": 0.95},
    messages_to_prompt=messages_to_prompt,
    completion_to_prompt=completion_to_prompt,
    device_map="auto"
    )

qa_dataset = generate_question_context_pairs(
    nodes, llm=llm, num_questions_per_chunk=2
)


"""
 过滤句子的函数，例如——以下是基于所提供上下文的两个问题
"""
# function to clean the dataset
def filter_qa_dataset(qa_dataset):
    """
    Filters out queries from the qa_dataset that contain certain phrases and the corresponding
    entries in the relevant_docs, and creates a new EmbeddingQAFinetuneDataset object with
    the filtered data.

    :param qa_dataset: An object that has 'queries', 'corpus', and 'relevant_docs' attributes.
    :return: An EmbeddingQAFinetuneDataset object with the filtered queries, corpus and relevant_docs.
    """

    # Extract keys from queries and relevant_docs that need to be removed
    queries_relevant_docs_keys_to_remove = {
        k for k, v in qa_dataset.queries.items()
        if 'Here are 2' in v or 'Here are two' in v
    }

    # Filter queries and relevant_docs using dictionary comprehensions
    filtered_queries = {
        k: v for k, v in qa_dataset.queries.items()
        if k not in queries_relevant_docs_keys_to_remove
    }
    filtered_relevant_docs = {
        k: v for k, v in qa_dataset.relevant_docs.items()
        if k not in queries_relevant_docs_keys_to_remove
    }

    # Create a new instance of EmbeddingQAFinetuneDataset with the filtered data
    return EmbeddingQAFinetuneDataset(
        queries=filtered_queries,
        corpus=qa_dataset.corpus,
        relevant_docs=filtered_relevant_docs
    )

# filter out pairs with phrases `Here are 2 questions based on provided context`
qa_dataset = filter_qa_dataset(qa_dataset)

print("=" * 10 + "自定义检索器" + "=" * 10)
"""
为了寻找最优检索器， 采用embedding模型和重排序器的组合。
最初建立一个基本的VectorIndexRetriever，检索节点后， 
引入一个重排序器进一步细化结果。
将similarity_top_k设置为10， 并用reranker选择前5名。
"""
embedding_model = "../embedding_model"
embed_model = HuggingFaceEmbedding(
    model_name = embedding_model
)
service_context = ServiceContext.from_defaults(llm=None, embed_model = embed_model)
vector_index = VectorStoreIndex(nodes, service_context=service_context)
vector_retriever = VectorIndexRetriever(index=vector_index, similarity_top_k = 10)


# Define Retriever
class CustomRetriever(BaseRetriever):
    """Custom retriever that performs both Vector search and Knowledge Graph search"""

    def __init__(
        self,
        vector_retriever: VectorIndexRetriever,
    ) -> None:
        """Init params."""

        self._vector_retriever = vector_retriever

    def _retrieve(self, query_bundle: QueryBundle) -> List[NodeWithScore]:
        """Retrieve nodes given query."""

        retrieved_nodes = self._vector_retriever.retrieve(query_bundle)

        if reranker != 'None':
            retrieved_nodes = reranker.postprocess_nodes(retrieved_nodes, query_bundle)
        else:
            retrieved_nodes = retrieved_nodes[:5]

        return retrieved_nodes

    async def _aretrieve(self, query_bundle: QueryBundle) -> List[NodeWithScore]:
        """Asynchronously retrieve nodes given query.

        Implemented by the user.

        """
        return self._retrieve(query_bundle)

    async def aretrieve(self, str_or_query_bundle: QueryType) -> List[NodeWithScore]:
        if isinstance(str_or_query_bundle, str):
            str_or_query_bundle = QueryBundle(str_or_query_bundle)
        return await self._aretrieve(str_or_query_bundle)


EMBEDDINGS = {
    "bge-large-en": HuggingFaceEmbedding(model_name='/data/database/hg-embed/bge-large-en-v1.5', device='cuda'), # You can use mean pooling by addin pooling='mean' parameter
    "bge-large-zh": HuggingFaceEmbedding(model_name='/data/database/hg-embed/bge-large-zh-v1.5', device='cuda'),
    "bce-base": HuggingFaceEmbedding(model_name='/data/database/hg-embed/bce-embedding-base_v1', device='cpu'),
    "JinaAI-Base": HuggingFaceEmbedding(model_name='/data/database/hg-embed/jina-embeddings-v2-base-en', device='cuda'),

}

RERANKERS = {
    "WithoutReranker": "None",
    "bce-reranker-base": SentenceTransformerRerank(model="/data/database/hg-embed/bce-reranker-base_v1", top_n=5),
    "bge-reranker-large": SentenceTransformerRerank(model="/data/database/hg-embed/bge-reranker-large", top_n=5)
}

# Loop over embeddings
for embed_name, embed_model in EMBEDDINGS.items():
    
    service_context = ServiceContext.from_defaults(llm=None, embed_model=embed_model)
    vector_index = VectorStoreIndex(nodes, service_context=service_context)
    vector_retriever = VectorIndexRetriever(index=vector_index, similarity_top_k=10, service_context=service_context)
    
    # Loop over rerankers
    for rerank_name, reranker in RERANKERS.items():

        print(f"Running Evaluation for Embedding Model: {embed_name} and Reranker: {rerank_name}")
        custom_retriever = CustomRetriever(vector_retriever)









