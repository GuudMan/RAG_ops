"""
1、较小的子块引用较大的父块
2、句子窗口检索
"""

from pathlib import Path
# from llama_hub.file.pdf.base import PDFReader
# from llama_index.core.response.notebook_utils import display_source_node
from llama_index.core.retrievers import RecursiveRetriever
from llama_index.core.query_engine import RetrieverQueryEngine
from llama_index.core import (VectorStoreIndex, 
                              ServiceContext, 
                              SimpleDirectoryReader,
                              StorageContext
                              )
from llama_index.core.node_parser import (SimpleNodeParser, 
                                          SentenceWindowNodeParser
                                          )
from llama_index.core.schema import IndexNode
# llama_index.core.schema.IndexNode
import json
from llama_index.core import Settings
from llama_index.llms.huggingface import HuggingFaceLLM
from llama_index.embeddings.huggingface import HuggingFaceEmbedding
from llama_index.core.postprocessor import MetadataReplacementPostProcessor

import os
os.environ['CUDA_VISIBLE_DEVICES'] = "0, 1"



### 步骤1：加载文档
# 使用PDFReader加载PDF文件， 并将文档的每一页合并为一个document对象

docs = SimpleDirectoryReader("../test_data").load_data()
# docs = SimpleDirectoryReader("../ops_txt_temp").load_data()

### 步骤2：文档解析为文本块（节点）
"""
文档拆分为文本块， 文本块在llamaindex中被称为“节点”， chunk大小定义为1024，ID是随机文本字符串
将节点ID格式化为遵循特定的格式
"""
node_parser = SimpleNodeParser.from_defaults(chunk_size=1024, chunk_overlap=32)
base_nodes = node_parser.get_nodes_from_documents(documents=docs)
for idx, node in enumerate(base_nodes):
    node.id_ = f"node--{idx}"
    # print(node)


"""
### 步骤3：选择embedding模型和LLM
定义两个模型
* embedding模型用于为每个文本块创建矢量嵌入， 这里HuggingFace中的FlagEmbedding模型
* LLM：用户查询和相关文本块喂给LLM, 让其生成相关上下文的答案
可以在ServiceContext中将这两个模型捆绑在一起， 并在以后得索引和查询步骤中使用它们

"""
def completion_to_prompt(completion):
   return f"<|im_start|>system\n<|im_end|>\n<|im_start|>user\n{completion}<|im_end|>\n<|im_start|>assistant\n"

def messages_to_prompt(messages):
    prompt = ""
    for message in messages:
        if message.role == "system":
            prompt += f"<|im_start|>system\n{message.content}<|im_end|>\n"
        elif message.role == "user":
            prompt += f"<|im_start|>user\n{message.content}<|im_end|>\n"
        elif message.role == "assistant":
            prompt += f"<|im_start|>assistant\n{message.content}<|im_end|>\n"

    if not prompt.startswith("<|im_start|>system"):
        prompt = "<|im_start|>system\n" + prompt

    prompt = prompt + "<|im_start|>assistant\n"

    return prompt


qwen = HuggingFaceLLM(
    model_name="../model_local/qwen/Qwen1.5-7B-Chat",
    tokenizer_name="../model_local/qwen/Qwen1.5-7B-Chat",
    context_window=30000, 
    max_new_tokens=2000,
    generate_kwargs={"temperature": 0.7, 
                     "top_k": 50, 
                     "top_p": 0.95},
    messages_to_prompt=messages_to_prompt,
    completion_to_prompt=completion_to_prompt,
    device_map="auto"
    )

embedding_model = "../embedding_model"
embed_model = HuggingFaceEmbedding(
    model_name = embedding_model
)

service_context = ServiceContext.from_defaults(
    llm=qwen, 
    embed_model=embed_model
)

print("===================步骤4: 创建索引、检索器和查询引擎===================")
"""
### 步骤4: 创建索引、检索器和查询引擎
索引、检索器和查询引擎是基于用户数据或文档进行问答的三个基本组件
索引是一种数据结构， 使我们能够从外部文档中快速检索用户查询的相关信息， 矢量存储索引获取文本块/节点，
然后创建每个节点的文本的矢量嵌入
"""
base_index = VectorStoreIndex(base_nodes, service_context=service_context)
# base_index = StorageContext.from_defaults(persist_dir='./data_base/vector_db/index_store_ops')

"""
Retriever用于获取和检索给定用户查询的相关信息
"""
base_retriever = base_index.as_retriever(similarity_top_k=2)

"""
查询引擎建立在索引和检索器上， 提供了一个通用接口卡来询问有关数据的问题
"""
query_engine_base = RetrieverQueryEngine.from_args(
    base_retriever, service_context=service_context
)
response = query_engine_base.query("什么是用户？")

print(response)


print("===================高级方法1： 较小的子块参照较大的父块===================")
"""
高级方法1： 较小的字块参照较大的父块
上面常规的方法中使用1024的固定块大小进行检索和合成
下面使用较小的子块进行检索， 并引用较大的父块进行合成
* 8个128大小的文本块
* 4个256大小的文本块
* 2个512大小的文本块
我们将大小为1024的原始文本块附加到文本块的列表中
"""

sub_chunk_sizes = [128, 256, 512]
sub_node_parsers = [
    SimpleNodeParser.from_defaults(chunk_size=c, chunk_overlap=32) for c in sub_chunk_sizes
]

all_nodes = []
for base_node in base_nodes:
    for n in sub_node_parsers:
        sub_nodes = n.get_nodes_from_documents([base_node])
        sub_inodes = [
            IndexNode.from_text_node(sn, base_node.node_id) for sn in sub_nodes
        ]
        all_nodes.extend(sub_inodes)
    # also add original node to node
    original_node = IndexNode.from_text_node(base_node, base_node.node_id)
    all_nodes.append(original_node)

all_nodes_dict = {n.node_id: n for n in all_nodes}
   
# print(all_nodes_dict)
# for key, value in all_nodes_dict.items():
#     print("key \n", key)
#     print("value \n", value)
#     print("==================")

print(type(all_nodes_dict))
print(list(all_nodes_dict.keys())[0])
print(list(all_nodes_dict.values())[0])
# json_str = json.dumps(all_nodes_dict)
# with open("./all_nodes_dict.json", mode="w+") as f:
#     f.write(str(all_nodes_dict))


print("===================高级方法1：步骤2 创建索引、检索器和查询引擎===================")
vector_index_chunk = VectorStoreIndex(
    all_nodes, 
    service_context=service_context
)
"""
Retriever：这里的关键是使用RecursiveRetriever遍历节点关系并基于“引用”获取节点。
这个检索器将递归地探索从节点到其他检索器/查询引擎的链接。
对于任何检索到的节点，如果其中任何节点是IndexNodes，
则它将探索链接的检索器/查询引擎并查询该引擎。
"""
vector_retriever_chunk = vector_index_chunk.as_retriever(
    similarity_top_k = 2)

"""
当verbose=0时，简单说就是不输出日志信息 ，进度条、loss、acc这些都不输出。
当verbose=1时，带进度条的输出日志信息，示例如下：
"""
retriever_chunk = RecursiveRetriever(
    "vector", 
    retriever_dict={"vector": vector_retriever_chunk}, 
    node_dict=all_nodes_dict, 
    verbose=1
)


"""
当我们提出问题并检索最相关的文本块时，它实际上会检索节点id指向父块的文本块，从而检索父块。
"""
nodes = retriever_chunk.retrieve("什么是裸金属")
for node in nodes:
    print(node)


"""
通过与以前相同的步骤，我们可以创建一个查询引擎作为通用接口来询问有关数据的问题。
"""
query_engin_chunk = RetrieverQueryEngine.from_args(
    retriever_chunk, service_context=service_context
)

response = query_engin_chunk.query(
    "RCP在IaaS架构下有哪些GSU虚机？"
)
print(response)



print("===================高级方法2：句子窗口检索===================")
"""
为了实现更细粒度的检索， 可以将文档解析为每个块的一个句子， 而不是使用更小的
子块。
在这种情况下， 单句将类似于上面方法1中提到的“子”块概念。
句子“窗口”（原句子两侧各5句）将类似于“父”组块概念。
换句话说， 在检索过程中使用单个句子， 并将检索到的带有句子窗口的句子传递给LLM
"""


print("===================高级方法2：步骤1-创建句子窗口节点解析器===================")
node_parser_window = SentenceWindowNodeParser.from_defaults(
    window_size=3, 
    window_metadata_key = "window",
    original_text_metadata_key = "original_text"
)
sentence_nodes = node_parser_window.get_nodes_from_documents(docs)
sentence_index = VectorStoreIndex(sentence_nodes, 
                                  service_context=service_context)


print("===================高级方法2：步骤2-创建查询引擎===================")
query_engine_window = sentence_index.as_query_engine(
    similarity_top_k=2,
    node_postprocessors=[
        MetadataReplacementPostProcessor(target_metadata_key="window")
    ],
)

window_response = query_engine_window.query(
    "RCP对AF请求的授权响应方式有哪几种？"
)
print(window_response)

window = window_response.source_nodes[0].node.metadata["window"]
sentence = window_response.source_nodes[0].node.metadata["original_text"]
print("window:", window)
print("---------------------")
print("Original Sentence", sentence)






