from transformers import AutoTokenizer, AutoModelForSeq2SeqLM, AutoModelForCausalLM
import torch
import os
os.environ['CUDA_VISIBLE_DEVICES'] = "0, 1"

#  初始化Llama-2
print("=" * 10 + "初始化Llama-2"  + "=" * 10)
model_path = "/root/autodl-tmp/langchainqwen14b/model_local/qwen/Qwen1.5-7B-Chat"
tokenizer = AutoTokenizer.from_pretrained(model_path)
model = AutoModelForCausalLM.from_pretrained(model_path)
print(model)
# 生成嵌入
print("=" * 10 + "生成嵌入"  + "=" * 10)
def generate_embeddings(text):
    inputs = tokenizer(text, return_tensors="pt", truncation=True, max_length=512)
    with torch.no_grad():
        outputs = model(**inputs)
    # return outputs.last_hidden_state.mean(dim=1).numpy()
    return outputs


data = [
    "Advances in solar panel efficiency have led to a significant reduction in cost.",
    "Wind turbines have become a major source of renewable energy in the past decade.",
    "The development of safer nuclear reactors opens new possibilities for clean energy.",
    # Add more abstracts as needed
]

# Generate embeddings for each abstract
embeddings = [generate_embeddings(abstract) for abstract in data]

# print(embeddings)









































































