
"""
以下是使用llamaindex进行加载和查询文档的案例
"""
from llama_index.core import (
    VectorStoreIndex, 
    SimpleDirectoryReader
)
from llama_index.core import Settings
from llama_index.llms.huggingface import HuggingFaceLLM
from llama_index.embeddings.huggingface import HuggingFaceEmbedding
import os
os.environ['CUDA_VISIBLE_DEVICES'] = "0, 1"


def completion_to_prompt(completion):
   return f"<|im_start|>system\n<|im_end|>\n<|im_start|>user\n{completion}<|im_end|>\n<|im_start|>assistant\n"

def messages_to_prompt(messages):
    prompt = ""
    for message in messages:
        if message.role == "system":
            prompt += f"<|im_start|>system\n{message.content}<|im_end|>\n"
        elif message.role == "user":
            prompt += f"<|im_start|>user\n{message.content}<|im_end|>\n"
        elif message.role == "assistant":
            prompt += f"<|im_start|>assistant\n{message.content}<|im_end|>\n"

    if not prompt.startswith("<|im_start|>system"):
        prompt = "<|im_start|>system\n" + prompt

    prompt = prompt + "<|im_start|>assistant\n"

    return prompt


qwen = HuggingFaceLLM(
    model_name="../model_local/qwen/Qwen1.5-7B-Chat",
    tokenizer_name="../model_local/qwen/Qwen1.5-7B-Chat",
    context_window=30000, 
    max_new_tokens=2000,
    generate_kwargs={"temperature": 0.7, 
                     "top_k": 50, 
                     "top_p": 0.95},
    messages_to_prompt=messages_to_prompt,
    completion_to_prompt=completion_to_prompt,
    device_map="auto"
    )

embedding_model = "../embedding_model"
Settings.embed_model = HuggingFaceEmbedding(
    model_name = embedding_model
)

Settings.llm = qwen


# 加载数据
documents = SimpleDirectoryReader("../test_data").load_data()


# 将文档对象解析为节点对象
index = VectorStoreIndex.from_documents(documents)

# 通过文档或节点建立索引
query_engine = index.as_query_engine()

# 响应是一个包含响应文本和源节点的响应对象

summary = query_engine.query("什么是用户组")
print(summary)

location = query_engine.query(
    "抽取文档中所有的实体与实体定义，以json形式返回， json中包括实体名称与定义")
print(location)
