
from llama_index.embeddings.huggingface import HuggingFaceEmbedding
from llama_index.llms.huggingface import HuggingFaceLLM
from llama_index.core import (VectorStoreIndex, 
                              SimpleDirectoryReader,
                              ServiceContext,
                              StorageContext, 
                              load_index_from_storage
                              )
from llama_index.core.node_parser import SimpleNodeParser
from llama_index.core.query_engine import RetrieverQueryEngine

import os
os.environ['CUDA_VISIBLE_DEVICES'] = "0, 1"


print("=" * 10 + "加载文档"  + "=" * 10)
documents = SimpleDirectoryReader(
    input_dir="../ops_txt_temp"
).load_data(show_progress=True)
print("len(documents)")
print(len(documents))
print(documents[0])

print("=" * 10 + "文档拆分成块"  + "=" * 10)
"""
注意到一件事， 文档在一个文件块中， 让我们将其拆分为多个块， Llamaindex中称为"Nodes"
"""

# create nodes parser
node_parser = SimpleNodeParser.from_defaults(chunk_size=1024)

# split into nodes
base_nodes = node_parser.get_nodes_from_documents(documents=documents)

print("len(base_nodes)")
print(len(base_nodes))
print(base_nodes[0])

"""
已经将较大的文档拆分为块， 也称为节点
"""

print("=" * 10 + "添加嵌入与LLM模型"  + "=" * 10)
def completion_to_prompt(completion):
   return f"<|im_start|>system\n<|im_end|>\n<|im_start|>user\n{completion}<|im_end|>\n<|im_start|>assistant\n"

def messages_to_prompt(messages):
    prompt = ""
    for message in messages:
        if message.role == "system":
            prompt += f"<|im_start|>system\n{message.content}<|im_end|>\n"
        elif message.role == "user":
            prompt += f"<|im_start|>user\n{message.content}<|im_end|>\n"
        elif message.role == "assistant":
            prompt += f"<|im_start|>assistant\n{message.content}<|im_end|>\n"

    if not prompt.startswith("<|im_start|>system"):
        prompt = "<|im_start|>system\n" + prompt

    prompt = prompt + "<|im_start|>assistant\n"

    return prompt

llm = HuggingFaceLLM(
    model_name="../model_local/qwen/Qwen1.5-7B-Chat",
    tokenizer_name="../model_local/qwen/Qwen1.5-7B-Chat",
    context_window=30000, 
    max_new_tokens=2000,
    generate_kwargs={"temperature": 0.7, 
                     "top_k": 50, 
                     "top_p": 0.95},
    messages_to_prompt=messages_to_prompt,
    completion_to_prompt=completion_to_prompt,
    device_map="auto"
    )

embedding_model = "../embedding_model"
embed_model = HuggingFaceEmbedding(
    model_name = embedding_model
)


print("=" * 10 + "创建索引"  + "=" * 10)
"""
创建一个索引，使用向量存储来存储嵌入， 对该文档执行查询以获得相关或类似的文档
"""
service_context = ServiceContext.from_defaults(
    embed_model=embed_model, 
    llm=llm
)
# creating index
index = VectorStoreIndex(nodes=base_nodes, 
                         service_context=service_context)
# create retriever
retriever = index.as_retriever(similarity_top_k = 2)

# test retriever
query = "ZXUN uMAC系统为什么采用服务化架构"
retrieved_nodes = retriever.retrieve(query)
print(retrieved_nodes)

print("=" * 10 + "展示查询到的相关文档"  + "=" * 10)
from llama_index.core.response.notebook_utils import display_source_node
for n in retrieved_nodes:
    display_source_node(n, source_length=15000)


print("\n\n\n=============================================================")
print("Node Texts")

for node in retrieved_nodes:
    print(node.text)
    # get word count for each doc
    print(len(node.text.split()))
    print("==" * 10)


print("=" * 10 + "将检索器插入查询引擎"  + "=" * 10)
# query retriever engine
query_engine = RetrieverQueryEngine.from_args(
    retriever=retriever,
    service_context=service_context
)

response = query_engine.query(query)
print("==========response==========")
print(response)

#  持久化向量存储
print("=" * 10 + "持久化向量存储"  + "=" * 10)

# check if data indexes already exists
if not os.path.exists("./data_base/llama_rag_9"):
    documents = SimpleDirectoryReader(
        input_dir="../ops_txt_temp").load_data(show_progress=True)
    
    # create nodes parser
    node_parser = SimpleNodeParser.from_defaults(chunk_size=1024)

    # split_into node
    base_nodes = node_parser.get_nodes_from_documents(documents=documents)

    # create index
    index = VectorStoreIndex(nodes=base_nodes, 
                             service_context=service_context)
    
    index.storage_context.persist()
else:
    # load existing index
    storage_context = StorageContext.from_defaults(
        persist_dir="./data_base/llama_rag_9")
    index = load_index_from_storage(storage_context=storage_context)

    
    
# create reteriever
retriever = index.as_retriever(similarity_top_k=2)

# query retriever engine
query_engine = RetrieverQueryEngine.from_args(
    retriever=retriever,
    service_context=service_context
)
# test response
response = query_engine.query(query)
print(response)
"""
项目目录中有一个名为data_base/llama_rag_9的文件夹，该文件夹存储了所有的嵌入，
意味着不必每次运行代码时都创建它们。它不仅更快，而且更便宜。
"""



























