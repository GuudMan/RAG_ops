from llama_index.core import download_loader
from pathlib import Path
from llama_index.core.node_parser import SimpleFileNodeParser, SimpleNodeParser
import os
import logging
import sys
from llama_index.core.callbacks import (
    CallbackManager
)
from llama_index.core import (SimpleDirectoryReader, 
                              ServiceContext,
                              VectorStoreIndex, 
                              )
from llama_index.core.retrievers import (VectorIndexRetriever, 
                                         BaseRetriever)

from llama_index.core import Settings
from llama_index.llms.huggingface import HuggingFaceLLM
from llama_index.core.schema import (QueryBundle, 
                                     QueryType,
                                     NodeWithScore)
from typing import List
from llama_index.core.postprocessor import SentenceTransformerRerank
from llama_index.callbacks.wandb import WandbCallbackHandler
from llama_index.core import load_index_from_storage
from llama_index.core.query_engine import PandasQueryEngine
from llama_index.core import (
  VectorStoreIndex, 
  SimpleKeywordTableIndex, 
  SimpleDirectoryReader, 
  StorageContext,
  ServiceContext
 )
from llama_index.embeddings.huggingface import HuggingFaceEmbedding
import os
os.environ['CUDA_VISIBLE_DEVICES'] = "2, 3"


print("=" * 10 + "加载数据"  + "=" * 10)
"""
llamaindex通过数据连机器Reader来加载数据， 数据连接器可以加载不同数据源的数据， 
并将数据格式化为Document对象， Document对象存储文本和对应的元数据。
"""

# PDFReader = download_loader("PDFReader")
# loader = PDFReader()
# docs = loader.load_data(file=Path("./12.pdf"))
documents = SimpleDirectoryReader("../ops_txt_temp").load_data()

print("=" * 10 + "开源LLM和嵌入"  + "=" * 10)
"""
使用开源模型， 对其进行量化。
通过简单地提供任务指令来生成针对任何任务（如，分类， 检索，聚类， 文本评估等）
定制的文本嵌入， 而无需任何微调，MTEB排行榜第14。
"""
def completion_to_prompt(completion):
   return f"<|im_start|>system\n<|im_end|>\n<|im_start|>user\n{completion}<|im_end|>\n<|im_start|>assistant\n"

def messages_to_prompt(messages):
    prompt = ""
    for message in messages:
        if message.role == "system":
            prompt += f"<|im_start|>system\n{message.content}<|im_end|>\n"
        elif message.role == "user":
            prompt += f"<|im_start|>user\n{message.content}<|im_end|>\n"
        elif message.role == "assistant":
            prompt += f"<|im_start|>assistant\n{message.content}<|im_end|>\n"

    if not prompt.startswith("<|im_start|>system"):
        prompt = "<|im_start|>system\n" + prompt

    prompt = prompt + "<|im_start|>assistant\n"

    return prompt

llm = HuggingFaceLLM(
    model_name="../model_local/qwen/Qwen1.5-7B-Chat",
    tokenizer_name="../model_local/qwen/Qwen1.5-7B-Chat",
    context_window=30000, 
    max_new_tokens=2000,
    generate_kwargs={"temperature": 0.7, 
                     "top_k": 50, 
                     "top_p": 0.95},
    messages_to_prompt=messages_to_prompt,
    completion_to_prompt=completion_to_prompt,
    device_map="auto"
    )


embedding_model = "../embedding_model"
embed_model = HuggingFaceEmbedding(
    model_name = embedding_model
)
Settings.llm = llm
Settings.embed_model = embed_model

service_context = ServiceContext.from_defaults(
    llm=llm, 
    chunk_size=256, 
    chunk_overlap=10,
    embed_model=embed_model
)

index = VectorStoreIndex.from_documents(documents, 
                                        service_context=service_context)

retriever = index.as_retriever(similarity_top_k=3)

"""
保证模型只根据上下文进行回答， 而不依赖于其训练数据， 即使可能已经学会了答案
"""
from llama_index.core.prompts import PromptTemplate

template = (
"提供如下的上下文信息 \n"
    "---------------------\n"
    "{context_str}"
    "\n---------------------\n"
    "根据提供的上下文信息， 回答问题: {query_str}\n"
    "除非有上述背景支持，否则不要给出答案.\n"
)

qa_template = PromptTemplate(template)

"""
使用两个更复杂的查询来测试刚刚创建的RAG应用程序。
"""

question = "RCP对AF请求的授权响应方式有哪几种？"
contexts = retriever.retrieve(question)
# print(contexts)

context_list = [n.get_content() for n in contexts]

prompt = qa_template.format(context_str="\n\n".join(context_list), 
                            query_str=question)
prompt_input = llm.completion_to_prompt(prompt)
output = llm.complete(prompt_input).text
print(output)

print("=" * 10 + "HyDEQueryTransform"  + "=" * 10)
from llama_index.core.indices.query.query_transform import HyDEQueryTransform
from llama_index.core.query_engine.transform_query_engine import TransformQueryEngine

index = VectorStoreIndex.from_documents(documents, 
                                        service_context=service_context)

query_engine = index.as_query_engine(similarity_top_k=3)


# hyde = HyDEQueryTransform(include_original=True)
# hyde_query_engine = TransformQueryEngine(query_engine, hyde)
# response = hyde_query_engine.query(question)
# print(response)

# print("=" * 10 + "查看hyde_doc"  + "=" * 10)
# query_bundle = hyde(question)
# hyde_doc = query_bundle.embedding_strs[0]
# print(hyde_doc)
# print(query_bundle.embedding_strs)


print("=" * 10 + "子问题"  + "=" * 10)
from llama_index.core.tools import QueryEngineTool, ToolMetadata
from llama_index.core.query_engine import SubQuestionQueryEngine
# setup base query engine as tool
query_engine_tools = [
    QueryEngineTool(
        query_engine=query_engine, 
        metadata=ToolMetadata(
            name="Sub-question query engine",
            description="Questions about actors",
        ),
    ),
]
query_engine_subques = SubQuestionQueryEngine.from_defaults(
    query_engine_tools=query_engine_tools, 
    service_context=service_context, 
    use_async = False
)

response_subques = query_engine_subques.query(question)
print(response_subques)

print("=" * 10 + "多步骤查询"  + "=" * 10)
from llama_index.core.query_engine import MultiStepQueryEngine

from llama_index.core.indices.query.query_transform.base import (
    StepDecomposeQueryTransform,
)
step_decompose_transform = StepDecomposeQueryTransform(llm=llm, verbose=True)

index_summary = "用于回答有关“5G运维文档”的知识"
query_engine_multistep = MultiStepQueryEngine(
    query_engine=query_engine, 
    query_transform=step_decompose_transform,
    index_summary=index_summary
)
response_multistep = query_engine_multistep.query(question)
print(response_multistep)


"""
只支持OpenAIPydanticProgram only supports OpenAI LLMs. 
Got: <class 'llama_index.llms.huggingface.base.HuggingFaceLLM'>
"""
print("=" * 10 + "路由器查询引擎"  + "=" * 10)
from llama_index.core.query_engine import RouterQueryEngine
from llama_index.core.selectors import PydanticSingleSelector
"""
为了在所有这些情况之间进行选择，我们可以使用RouterQueryEngine——
我们为LLM提供了一组用于查询转换的工具，
并让它根据输入提示来决定应用的最佳工具。
"""
query_engine_router = RouterQueryEngine(
    selector=PydanticSingleSelector.from_defaults(),
    query_engine_tools = [
        query_engine,
        query_engine_subques,
        query_engine_multistep
        
    ]
)
response_router = query_engine_router.query(question)
print(response_router)












