import os
from langchain.embeddings.huggingface import HuggingFaceEmbeddings
from langchain.vectorstores import Chroma
from langchain.chains import RetrievalQA
from langchain.llms.base import LLM
from transformers import AutoModelForCausalLM, GenerationConfig,AutoTokenizer
from typing import Optional, Any, List
from langchain.callbacks.manager import CallbackManagerForLLMRun
import tiktoken
import streamlit as st
import torch
os.environ['CUDA_VISIBLE_DIVICES'] = '2, 3'

print("=" * 10 + "加载文档"  + "=" * 10)
def load_document(file):

    name, extension = os.path.splitext(file)
    if extension == '.pdf':
        from langchain.document_loaders import PyPDFLoader
        print(f"Loading {file}")
        loader = PyPDFLoader(file)
    elif extension == ".docx":
        from langchain.document_loaders import Docx2txtLoader
        print(f'Loading {file}')
        loader = Docx2txtLoader(file)
    elif extension == ".txt":
        from langchain.document_loaders import TextLoader
        loader = TextLoader(file)
    else:
        print("Document format is not supported!")
        return None
    
    data = loader.load()
    return data



# 数据分块对RAG系统非常重要，对数据进行分块以便于嵌入。
# 这确保可以保留高效的上下文和信息检索

def chunk_data(data, chunk_size=256, chunk_overlap=20):
    from langchain.text_splitter import RecursiveCharacterTextSplitter
    text_splitter = RecursiveCharacterTextSplitter(chunk_size=chunk_size, 
                                                   chunk_overlap=chunk_overlap)
    chunks = text_splitter.split_documents(data)
    return chunks


print("=" * 10 + "创建嵌入"  + "=" * 10)

# 使用大模型创建嵌入， 并将它们高效地存储在ChromaDB中， 可以快速检索信息

def create_embeddings(chunks):
    embeddings = HuggingFaceEmbeddings(model_name="../embedding_model")
    vector_store = Chroma.from_documents(chunks, 
                                         embeddings, 
                                         persist_directory="./data_base/vector_db/rag_6")
    return vector_store


print("=" * 10 + "使用Streamlit构建聊天界面"  + "=" * 10)

# Streamlit的简单性可以在RAG LLM应用程序中大放异彩，
# 可毫不费力地将用户输入链接到后端处理。通过Streamlit的初始化和布局设计， 
# 用户可以上传文档和管理数据。后端处理这些输入， 直接在Streamlit界面中返回响应， 
# 展示了前端和后端操作的无缝集成


class Qwen2_LLM(LLM):
    # 基于本地 Qwen2 自定义 LLM 类
    tokenizer: AutoTokenizer = None
    model: AutoModelForCausalLM = None
        
    def __init__(self, mode_name_or_path :str):

        super().__init__()
        print("正在从本地加载模型...")
        self.tokenizer = AutoTokenizer.from_pretrained(mode_name_or_path, use_fast=False)
        self.model = AutoModelForCausalLM.from_pretrained(mode_name_or_path, torch_dtype=torch.bfloat16, device_map="auto")
        self.model.generation_config = GenerationConfig.from_pretrained(mode_name_or_path)
        print("完成本地模型的加载")
        
    def _call(self, prompt : str, stop: Optional[List[str]] = None,
                run_manager: Optional[CallbackManagerForLLMRun] = None,
                **kwargs: Any):

        messages = [{"role": "user", "content": prompt }]
        input_ids = self.tokenizer.apply_chat_template(messages, 
                                                       tokenize=False, 
                                                       add_generation_prompt=True)
        model_inputs = self.tokenizer([input_ids], 
                                      return_tensors="pt").to('cuda')
        generated_ids = self.model.generate(model_inputs.input_ids,
                                            max_new_tokens=512)
        generated_ids = [
            output_ids[len(input_ids):] for input_ids, 
            output_ids in zip(model_inputs.input_ids, 
                              generated_ids)
        ]
        response = self.tokenizer.batch_decode(generated_ids, 
                                               skip_special_tokens=True)[0]
        
        return response
    @property
    def _llm_type(self) -> str:
        return "Qwen2_LLM"
    

# from LLM import Qwen2_LLM
llm = Qwen2_LLM(mode_name_or_path = "/root/autodl-tmp/langchainqwen14b/model_local/qwen/Qwen1.5-7B-Chat")


def ask_and_get_answer(vectot_store, q, k=3):
    retriever = vectot_store.as_retriever(search_type="similarity", 
                                          search_kwargs={'k':k})
    chain = RetrievalQA.from_chain_type(llm=llm, 
                                        chain_type='stuff', 
                                        retriever=retriever)
    answer = chain.run(q)
    return answer
    

# calculate embedding cost using tiktoken
def calculate_embedding_cost(texts):
    enc = tiktoken.encoding_for_model('text-embedding-ada-002')
    total_tokens = sum([len(enc.encode(page.page_content)) for page in texts])

    return total_tokens, total_tokens / 1000 * 0.0004


# clear the chat history from streamlit session state
def clear_history():
    if 'history' in st.session_state:
        del st.session_state['history']

if __name__ == '__main__':
    import os
    from dotenv import load_dotenv, find_dotenv
    load_dotenv(find_dotenv(), override=True)

    
    # Streamlit中创建文本输入字段并处理用户输入。通过这种设置， 
    # 用户可以无缝直观地与人工智能应用程序交互。
    
    st.image('./img.jpg')
    st.subheader('LLM Question-Answering Application')

    with st.sidebar:
        # text_input for the 
        cuda_devices = st.text_input('CUDA DEVICES', type='default')
        if cuda_devices:
            os.environ['CUDA_VISIBLE_DEVICES'] = cuda_devices
        
        # file uploader widget
        # uploaded_file = st.file_uploader('Upload a file:', 
        #                                  type=['pdf', 'docx', 'txt'])
        uploaded_files = st.file_uploader("Choose a txt file", 
                                          type=['txt'],
                                          accept_multiple_files=True)
        
        # print(uploaded_files)
        # chunk size number widget
        chunk_size = st.number_input('Chunk size:', 
                                     min_value=100, 
                                     max_value=2048, 
                                     value=512, 
                                     on_change=clear_history)
        # k number input widget
        k = st.number_input('k', 
                            min_value=1, 
                            max_value=20, 
                            value=3, 
                            on_change=clear_history)
        # add data button widget
        add_data = st.button('Add Data', on_click=clear_history)

        if uploaded_files and add_data: # if the user browsed a file
            with st.spinner('Reading, chunking and embedding file ...'):
                # writing the file from RAM to the current directory on disk
                for uploaded_file in uploaded_files:
                    # print("uploaded_file")
                    # print(uploaded_file)
                    bytes_data = uploaded_file.read()
                
                    file_name = os.path.join('./', "txt_temp.txt")
                    with open(file_name, 'ab') as f:
                        f.write(bytes_data)
                
                data = load_document(file_name)
                chunks = chunk_data(data, chunk_size=chunk_size)
                st.write(f'Chunk size:{chunk_size}, Chunks:{len(chunks)}')

                tokens, embedding_cost = calculate_embedding_cost(chunks)
                st.write(f'Embedding cost: ${embedding_cost:.4f}')

                # creating the embeddings and retruning the Chroma vector store
                vector_store = create_embeddings(chunks)

                # saving the vector store in the streamlit session state
                st.session_state.vs = vector_store
                st.success('File uploaded, chunked and embedded successfully.')

    # 检索答案和增强用户交互
    # user's question text input widget
    q = st.text_input('根据你的文档提问')
    if q: # if user entered a question and hit enter
        if 'vs' in st.session_state:  # if there's the vector store
            vector_store = st.session_state.vs
            st.write(f'k:{k}')
            answer = ask_and_get_answer(vector_store, q, k)

            st.text_area('LLM Answer:', value=answer)
            st.divider()

            # if there's no chat history in the session state
            if 'history' not in st.session_state:
                st.session_state.history = ''
            
            # the current question and answer
            value = f'Q:{q} \nA:{answer}'

            st.session_state.history = f'{value} \n {"-" * 100} \n {st.session_state.history}'
            h = st.session_state.history

            # text area widget for the chat history
            st.text_area(label='Chat History', 
                         value=h, 
                         key='history', 
                         height=400)
            

# 执行程序， 在当前文本的路径下终端执行
# streamlit run ./xxx.py





