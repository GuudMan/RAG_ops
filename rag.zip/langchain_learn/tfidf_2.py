from rank_bm25 import BM25Okapi
import jieba
import json

pdf_contents = ["", ""]
questions = ["", ""]
pdf_content_words = [jieba.lcut(x['content']) for x in pdf_contents]
bm25 = BM25Okapi(pdf_content_words)

for query_idx in range(len(questions)):
    doc_scores = bm25.get_scores(jieba.lcut(questions[query_idx]["question"]))
    max_socre_page_idx = doc_scores.argsort()[-1] + 1
    questions[query_idx]['reference'] = 'page_' + str(max_socre_page_idx)

with open('submit.json', 'w', encoding='utf-8') as up:
    json.dump(questions, up, ensure_ascii=False, indent=4)
    