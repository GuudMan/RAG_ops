import os
from dotenv import load_dotenv
from pymongo import MongoClient
from langchain.embeddings import HuggingFaceEmbeddings
from langchain.llms import HuggingFaceHub
from langchain.document_loaders import TextLoader, UnstructuredHTMLLoader,UnstructuredFileLoader
from langchain.vectorstores import Chroma
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.embeddings import SentenceTransformerEmbeddings
from langchain.prompts import PromptTemplate
from dotenv import load_dotenv
from langchain.embeddings.huggingface import HuggingFaceEmbeddings
from langchain.llms.base import LLM
from langchain.callbacks.manager import CallbackManagerForLLMRun
from transformers import AutoTokenizer, AutoModelForCausalLM, GenerationConfig, LlamaTokenizerFast
from typing import Any, List, Optional
import torch
import os
os.environ['CUDA_VISIBLE_DEVICES'] = '0, 1'


# load environment variable from .env file
load_dotenv(override=True)
MONGO_URI = os.environ["MONGO_URI"]
DB_NAME = "pdfchatbot"
COLLECTION_NAME = "advanceRAGParentChild"

embeddings = HuggingFaceEmbeddings(model_name="../embedding_model")

client = MongoClient(MONGO_URI)
db = client[DB_NAME]
collection = db[COLLECTION_NAME]

# 步骤2：数据加载和分块
print("=" * 10 + "步骤2：数据加载和分块"  + "=" * 10)
from langchain.document_loaders import PyPDFLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter

parent_splitter = RecursiveCharacterTextSplitter(chunk_size=2000)
child_splitter = RecursiveCharacterTextSplitter(chunk_size=200)

def process_pdf(file):
    loader = PyPDFLoader(file.name)
    docs = loader.load()
    parent_docs = parent_splitter.split_documents(docs)

    # Process parent documents
    for parent_doc in parent_docs:
        parent_doc_content = parent_doc.page_content.replace('\n', ' ')
        parent_id = collection.insert_one({
            'document_type':'parent',
            'content': parent_doc_content
        }).inserted_id
    

        # process child documents
        child_docs = child_splitter.split_documents([parent_doc])
        for child_doc in child_docs:
            child_doc_content = child_doc.page_content.replace("\n", ' ')
            child_embedding = embeddings.embed_documents([child_doc_content])[0]
            collection.insert_one({
                "document_type": 'type',
                'content': child_doc_content, 
                'embedding':child_embedding, 
                'parent_ref': parent_id
            })
    return "PDF processing complete"



# 步骤3：查询嵌入和矢量搜索
print("=" * 10 + "步骤3：查询嵌入和矢量搜索"  + "=" * 10)
"""
提交查询时， 将其转换为嵌入， 并执行向量搜索以找到最相关的子文档。
链接回它们的父文档以获取上下文
"""
# Function to embed a query and perform a vector search
def query_and_display(query):
    query_embedding = embeddings.embed_documents([query])[0]

    # Retrieve relevant child documents based on query
    child_docs = collection.aggregate([{
        "$vectorSearch":{
            "index": "vector_index",
            "path": "embedding",
            "queryVector": query_embedding, 
            "numCandidate": 10
        }
    }])

    # Fetch corresponding parent documents for additional context
    parent_docs = [collection.find_one({"_id": doc['parent_ref']}) for doc in child_docs]
    return parent_docs, child_docs

# 步骤4：通过上下文感知生成响应
"""
在识别出相关文档后， 为LLM创建一个提示， 其中包括用户的查询和匹配文档中的内容， 这确保了
响应具有信息性和上下文相关性
"""

class Qwen2_LLM(LLM):
    # 基于本地 Qwen2 自定义 LLM 类
    tokenizer: AutoTokenizer = None
    model: AutoModelForCausalLM = None
        
    def __init__(self, mode_name_or_path :str):

        super().__init__()
        print("正在从本地加载模型...")
        self.tokenizer = AutoTokenizer.from_pretrained(mode_name_or_path, use_fast=False)
        self.model = AutoModelForCausalLM.from_pretrained(mode_name_or_path, torch_dtype=torch.bfloat16, device_map="auto")
        self.model.generation_config = GenerationConfig.from_pretrained(mode_name_or_path)
        print("完成本地模型的加载")
        
    def _call(self, prompt : str, stop: Optional[List[str]] = None,
                run_manager: Optional[CallbackManagerForLLMRun] = None,
                **kwargs: Any):

        messages = [{"role": "user", "content": prompt }]
        input_ids = self.tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
        model_inputs = self.tokenizer([input_ids], return_tensors="pt").to('cuda')
        generated_ids = self.model.generate(model_inputs.input_ids,max_new_tokens=512)
        generated_ids = [
            output_ids[len(input_ids):] for input_ids, output_ids in zip(model_inputs.input_ids, generated_ids)
        ]
        response = self.tokenizer.batch_decode(generated_ids, skip_special_tokens=True)[0]
        
        return response
    @property
    def _llm_type(self) -> str:
        return "Qwen2_LLM"
    

# from LLM import Qwen2_LLM
llm = Qwen2_LLM(mode_name_or_path = "/root/autodl-tmp/langchainqwen14b/model_local/qwen/Qwen1.5-7B-Chat")



def generate_response(query, parent_docs, child_docs):
    response_content = " ".join([doc['content'] for doc in parent_docs if doc])
    chat_completion = llm(query)
    return chat_completion.choices[0].message.content


# 第五步：串联所有组件
print("=" * 10 + "串联所有组件"  + "=" * 10)
import gradio as gr

"""
将这些元素组合一个连贯的界面， 用户可以在其中上传文档并提出问题
"""
with gr.Blocks(css=".gradio-container {background-color: AliceBlue}") as demo:
    gr.Markdown("Generative AI Chatbot - Upload your file and Ask questions")

    with gr.Tab("Upload PDF"):
        with gr.Row():
            pdf_input = gr.File()
            pdf_output = gr.Textbox()
        pdf_button = gr.Button("Upload PDF")

    with gr.Tab("Ask question"):
        question_input = gr.Textbox(label="Your Question")
        answer_output = gr.Textbox(label="LLM Response and Retrieved Documents", interactive=False)
        question_button = gr.Button("Ask")


    question_button.click(query_and_display, inputs=[question_input], outputs=answer_output)
    pdf_button.click(process_pdf, inputs=pdf_input, outputs=pdf_output)

demo.launch()

























