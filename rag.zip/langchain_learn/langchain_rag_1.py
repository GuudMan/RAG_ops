import os
import torch
from langchain.prompts.chat import (
    ChatPromptTemplate, 
    HumanMessagePromptTemplate, 
    SystemMessagePromptTemplate
)
from langchain import PromptTemplate
from langchain import HuggingFacePipeline
from langchain.vectorstores import Chroma
from langchain.schema import AIMessage, HumanMessage
from langchain.memory import ConversationBufferMemory
from langchain.embeddings import HuggingFaceBgeEmbeddings
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.document_loaders import (UnstructuredMarkdownLoader, 
                                        UnstructuredURLLoader)
from langchain.chains import (LLMChain, 
                              SimpleSequentialChain,
                              ConversationalRetrievalChain
                              )
from langchain.chains import RetrievalQA
from transformers import (BitsAndBytesConfig, 
                          AutoModelForCausalLM, 
                          AutoTokenizer, 
                          GenerationConfig, 
                          pipeline
                          )
import warnings
warnings.filterwarnings('ignore')

os.environ['CUDA_VISIBLE_DEVICES'] = "0, 1"

# 文本生成pipeline
MODEL_NAME = "../model_local/qwen/Qwen1.5-7B-Chat"
"""
quantiation_config = BitsAndBytesConfig(...)。这里， 使用BitsAndBytesConfig定义量化
配置。量化是一种降低深度学习模型的内存和计算需求的技术，
通常通过使用更少的比特（在外面的情况下为4bit）来表示模型参数
"""
quantization_config = BitsAndBytesConfig(
    load_in_4bit=True, 
    bnb_4bit_compute_dtype=torch.float16,
    bnb_4bit_quant_type='nf4',
    bnb_4bit_use_double_quant=True
)
# 初始化大模型的tokenizer， 允许预处理输入到模型的文本数据
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME, 
                                          use_fast=True)
tokenizer.pad_token = tokenizer.eos_token
# 初始化用于因果建模的预训练语言模型， 
model = AutoModelForCausalLM.from_pretrained(MODEL_NAME, 
                                             torch_dtype=torch.float16, 
                                             trust_remote_code=True, 
                                             device_map="auto", 
                                             quantization_config=quantization_config)
# 为模型创建一个生成配置， 制定各种与生成相关的设置， 如令牌的最大数量、采样温度、top-p采样
# 与重复惩罚
generation_config = GenerationConfig.from_pretrained(MODEL_NAME)

generation_config.max_new_tokens = 1024
generation_config.temperature = 0.0001
generation_config.top_p = 0.95
generation_config.do_sample = True
generation_config.repetition_penalty = 1.15
# 使用pipeline函数创建一个文本生成管道， 这个管道是为文本生成而设置， 它将预训练的模型、
# 标记器和生成配置作为输入，它被配置为返回全文输出。
pipeline = pipeline("text-generation", 
                    model=model, 
                    tokenizer=tokenizer, 
                    generation_config = generation_config
                    )


llm = HuggingFacePipeline(
    pipeline = pipeline
)

query = "左眼皮一直在跳动"
result = llm(
    query
)
print(result)

"""
### 五、Embedding模型

在配置基础LLM之后， 继续配置embedding模型。每个文档都应该转换为embedding向量，以便使用用户的查询进行语义搜索。该查询也应该被embedding。为了实现这一点， 将利用阿里的GTE模型。
使用HuggingFaceEmbeddings类， 这是本地管道包装器， 用于与hugging face hub上托管的GTE模型进行交互。
"""
embeddings = HuggingFaceBgeEmbeddings(
    model_name="../embedding_model",
    model_kwargs = {"device":"cuda"},
    encode_kwargs = {"normalize_embeddings":True}
)

"""
#### Prompt Template
PromptTemplate通过结构化Prompt格式使模型按照用户期望的格式输出， 模版包括指令、few-shot
例子以及适合特定任务的特定上下文和问题
"""
template = """
|im_start|
扮演一名教授高中生的机器学习工程师。
{text} 
|im_start|
"""

prompt = PromptTemplate(
    input_variables=["text"],
    template=template,
)

query = "用两三句话解释一下神经网络："
result = llm(prompt.format(text=query))
print(result)

print("===============load_documents=============")
urls = [
      "https://www.hiberus.com/expertos-ia-generativa-ld",
    "https://www.hiberus.com/en/experts-generative-ai-ld"
]

loader = UnstructuredURLLoader(urls=urls)

documents = loader.load()

print(len(documents))
print(documents[1])

"""
由于两个文档数量较大， 找过了大模型的上下文窗口大小， 因此需要将
文档按照1024个tokens大小进行切分， 生成21个较小的chunks， 并且为
了保证上下文的连续性， chunk与chunk直接设置64个重叠tokens
"""
print("===============text_splitter=============")
text_splitter = RecursiveCharacterTextSplitter(
                chunk_size=1024, 
                chunk_overlap=64
                )

texts_chunks = text_splitter.split_documents(documents)

print(len(texts_chunks))
# print(texts_chunks[0])

print("===============数据注入-向量数据库=============")
"""
对数据分块后， 将对分块数据进行embedding并存储到向量数据库Chromdb中
"""
# db = Chroma.from_documents(texts_chunks, 
#                            embeddings, 
#                            persist_directory="../data_base/vector_db/rag_1")

db = Chroma(persist_directory='./data_base/vector_db/rag_1', 
                   embedding_function=embeddings)
"""
数据被添加索引后， 可以在Prompt模版中添加RAG模型赋予营销经理专家的角色。
此外， 为了将LLM与矢量数据库检索功能相结合， 使用了关键的链接组件
RetrievalQA, 其中， k=2， 这种设置确保检索器输出两个相关的块， 然后LLM在
提出问题时使用这两个块来制定答案。
"""

template = """
|im_start|
扮演 Hiberus 营销经理专家。利用以下信息回答最后的问题。
{context}

{question} 

|im_end|
"""

prompt = PromptTemplate(template=template, 
                        input_variables = ['context', 'question'])

qa_chain = RetrievalQA.from_chain_type(
    llm = llm,
    chain_type="stuff",
    retriever = db.as_retriever(search_kwargs={"k":3}),
    return_source_documents=True,
    chain_type_kwargs={"prompt":prompt}
)

print("===============执行查询=============")

query = "什么是GenAI Ecosystem?"
result = qa_chain(query)
result = result["result"].strip()
print(result)

# 问题2

print("===============执行查询： 问题2=============")

query = "Why Hiberus has created GenAI Ecosystem?"
result_ = qa_chain(
    query
)
result = result_["result"].strip()
print(result)


print("===============问答=============")

custom_template = """You are an Hiberus Marketing Manager AI Assistant. Given the
following conversation and a follow up question, rephrase the follow up question
to be a standalone question. At the end of standalone question add this
'Answer the question in English language.' If you do not know the answer reply
 with 'I am sorry, I dont have enough information'.
Chat History:
{chat_history}
Follow Up Input: {question}
Standalone question:
"""
CUSTOM_QUESTION_PROMPT = PromptTemplate.from_template(custom_template)

memory = ConversationBufferMemory(memory_key="chat_history",
                                  return_messages=True)

qa_chain = ConversationalRetrievalChain.from_llm(
    llm = llm, 
    retriever=db.as_retriever(search_kwargs={"k": 2}, 
                              memory=memory, 
                              condense_question_prompt=CUSTOM_QUESTION_PROMPT)
                              )

history = memory.chat_memory.messages


print("===============问答, 测试1=============")
query = "你是谁？"
result_ = qa_chain({"question": query, "chat_history": history})
result_ = result_["answer"].strip()
print(result_)

print("===============问答, 测试2=============")
history = memory.chat_memory.messages
query = "What is GenIA Ecosystem?"
result_ = qa_chain({"question": query, "chat_history": history})
result = result_["answer"].strip()
print(result_)

print("===============打印历史：history=============")
history = memory.chat_memory.messages
print(history)














