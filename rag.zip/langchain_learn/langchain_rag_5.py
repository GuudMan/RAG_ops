
import os

from langchain.document_transformers import (
    EmbeddingsClusteringFilter,
    EmbeddingsRedundantFilter,
)
from langchain.embeddings import HuggingFaceEmbeddings, OpenAIEmbeddings,HuggingFaceBgeEmbeddings
from langchain.retrievers import ContextualCompressionRetriever
from langchain.retrievers.document_compressors import DocumentCompressorPipeline
from langchain.document_transformers import LongContextReorder
from langchain.retrievers.merger_retriever import MergerRetriever
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.vectorstores import FAISS,Chroma
from langchain.document_loaders import PyPDFLoader
from langchain.llms import HuggingFaceHub
from langchain.document_loaders import TextLoader, UnstructuredHTMLLoader,UnstructuredFileLoader
from langchain.vectorstores import Chroma
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.embeddings import SentenceTransformerEmbeddings
from langchain.prompts import PromptTemplate
from dotenv import load_dotenv
from langchain.embeddings.huggingface import HuggingFaceEmbeddings
from langchain.llms.base import LLM
from langchain.callbacks.manager import CallbackManagerForLLMRun
from transformers import AutoTokenizer, AutoModelForCausalLM, GenerationConfig, LlamaTokenizerFast
from typing import Any, List, Optional
import torch
import os
os.environ['CUDA_VISIBLE_DEVICES'] = '0, 1'


# 设置Embedding模型
print("=" * 10 + "设置Embedding模型"  + "=" * 10)
hf_embeddings = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2",
                                      model_kwargs={"device":"cpu"},
                                      encode_kwargs = {'normalize_embeddings': False})
hf_bge_embeddings = HuggingFaceBgeEmbeddings(model_name="BAAI/bge-large-en",
                                             model_kwargs={"device":"cpu"},
                                             encode_kwargs = {'normalize_embeddings': False})
# openai_embeddings = OpenAIEmbeddings(openai_api_key=OPENAI_API_KEY)

print("=" * 10 + "数据处理"  + "=" * 10)
loader_mh = PyPDFLoader("health_document.pdf")
document_mh = loader_mh.load()
print(len(document_mh))

loader_espos = PyPDFLoader("health_document_w.pdf")
document_esops = loader_espos.load()
print(len(document_esops))

# 把文档split为块
print("=" * 10 + "把文档split为块"  + "=" * 10)
text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, 
                                               chunk_overlap=200)
text_mh = text_splitter.split_documents(document_mh)
text_esops = text_splitter.split_documents(document_esops)
print(len(text_mh))
print(len(text_esops))

# 实例化两个Chromadb索引，每一个都使用不同的embedding
print("=" * 10 + "实例化两个Chromadb索引，每一个都使用不同的embedding"  + "=" * 10)
import chromadb
ABS_PATH = os.path.dirname(os.path.abspath("."))
DB_DIR = os.path.join(ABS_PATH, "db")

client_settings = chromadb.config.Settings(
    is_persistent = True, 
    persist_directory=DB_DIR, 
    anonymized_telemetry = False
)

mh_vectorstore = Chroma.from_documents(text_mh, 
                                       hf_bge_embeddings, 
                                       client_settings=client_settings, 
                                       collection_name="mental_health", 
                                       collection_metadata={"hnsw": "cosine"},
                                       persist_directory="./data_base/vector_db/rag_4"
                                       )
esops_vectorstore = Chroma.from_documents(text_esops, 
                                          hf_embeddings, 
                                          client_settings=client_settings, 
                                          collection_name="esops",
                                          collection_metadata={"hnsq":"cosine"},
                                          persist_directory="./data_base/vector_db/rag_4"
                                          )

print("=" * 10 + "加载VectorStore"  + "=" * 10)
"""
定义具有两个不同嵌入和不同搜索类型的两个不同检索器
"""
retriever_mh = mh_vectorstore.as_retriever(search_type="mmr", 
                                           search_kwargs={"k":5, 
                                                          "include_metadata":1}
                                           )
retriever_esops = esops_vectorstore.as_retriever(search_type="mmr", 
                                                 search_kwargs={"k":5, 
                                                                "include_metadata":1}
                                                 )
# 合并所有检索器
print("=" * 10 + "合并所有检索器"  + "=" * 10)
lotr = MergerRetriever(retrievers=[retriever_mh, retriever_esops])

for chunks in lotr.get_relevant_documents("What is esops"):
    print(chunks.page_content)

# 从合并的检索器中删除多余的结果
print("=" * 10 + "从合并的检索器中删除多余的结果"  + "=" * 10)
"""
EmbeddingsRedundantFilter通过比较冗余文档的嵌入来删除冗余文档
"""
embeddings = HuggingFaceEmbeddings(model_name="../embedding_model")
filter = EmbeddingsClusteringFilter(embeddings=embeddings)
pipeline = DocumentCompressorPipeline(transformers=[filter])
compression_retriever = ContextualCompressionRetriever(base_compressor=pipeline, 
                                                       base_retriever=lotr)

# 通过原始检索器分数排序， 来获得最终文档
"""
这个过滤器把文档向量划分为聚类或意义的“中心”
然后， 将为组中结果选择离该中心最近的文档
默认情况下， 结果文档按簇进行排序/分组
如果希望最终文档按原始检索器分数排序， 需要将“排序”参数添加为True
"""
filter_ordered_by_retriever = EmbeddingsClusteringFilter(
    embeddings=embeddings, 
    num_clusters=10, 
    num_closest=1, 
    sorted=True
)
pipeline = DocumentCompressorPipeline(transformers=[filter_ordered_by_retriever])
compression_retriever = ContextualCompressionRetriever(
    base_compressor=pipeline, base_retriever=lotr
)

# 重新排序结果以避免性能下降
print("=" * 10 + "重新排序结果以避免性能下降"  + "=" * 10)
lotr = MergerRetriever(retrievers=[retriever_mh, retriever_esops])
query = "what is ESOPS?"
docs = lotr.get_relevant_documents(query)
print(docs)


#  重新排序的文档（处理中间丢失的文档
print("=" * 10 + "重新排序的文档（处理中间丢失的文档）"  + "=" * 10)
reordering = LongContextReorder()
reordered_docs = reordering.transform_documents(docs)
print(reordered_docs)

# 在应用LongContextReorder后，可以看到检索到的上下文的顺序有所不同，
# 该命令根据上下文与所请求查询的相关性对检索到的语境进行重新排序。

# 设置筛选和LongContext Retriever管道
print("=" * 10 + "设置筛选和LongContext Retriever管道"  + "=" * 10)
from re import search
filter = EmbeddingsClusteringFilter(embeddings=embeddings)
reordering = LongContextReorder()
pipeline = DocumentCompressorPipeline(transformers=[filter, reordering])
compression_retriever_reordered = ContextualCompressionRetriever(
    base_compressor=pipeline, 
    base_retriever=lotr, 
    search_kwargs={"k": 5, 
                   "include_metadata": True
                   }
)
docs = compression_retriever_reordered.get_relevant_documents("what is esops?")
print(len(docs))
print(docs[0].page_content)
print(compression_retriever_reordered.get_relevant_documents("what is esops?"))


#  使用Langchain实现生成管道
print("=" * 10 + "使用Langchain实现生成管道"  + "=" * 10)
# 设置llm
# from langchain.llms import llamacpp
# llms = llamacpp(streaming=True, 
#                 model_path = "zephyr-7b-beta.Q4_K_M.gguf",
#                 max_tokens = 1500, 
#                 temperature=0.75,
#                 top_p = 1,
#                 gpu_layers=0,
#                 stream=True, 
#                 verbose=True, 
#                 n_threads=int(os.cpu_count()/2),
#                 n_ctx=4096
#                 )
class Qwen2_LLM(LLM):
    # 基于本地 Qwen2 自定义 LLM 类
    tokenizer: AutoTokenizer = None
    model: AutoModelForCausalLM = None
        
    def __init__(self, mode_name_or_path :str):

        super().__init__()
        print("正在从本地加载模型...")
        self.tokenizer = AutoTokenizer.from_pretrained(mode_name_or_path, use_fast=False)
        self.model = AutoModelForCausalLM.from_pretrained(mode_name_or_path, torch_dtype=torch.bfloat16, device_map="auto")
        self.model.generation_config = GenerationConfig.from_pretrained(mode_name_or_path)
        print("完成本地模型的加载")
        
    def _call(self, prompt : str, stop: Optional[List[str]] = None,
                run_manager: Optional[CallbackManagerForLLMRun] = None,
                **kwargs: Any):

        messages = [{"role": "user", "content": prompt }]
        input_ids = self.tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
        model_inputs = self.tokenizer([input_ids], return_tensors="pt").to('cuda')
        generated_ids = self.model.generate(model_inputs.input_ids,max_new_tokens=512)
        generated_ids = [
            output_ids[len(input_ids):] for input_ids, output_ids in zip(model_inputs.input_ids, generated_ids)
        ]
        response = self.tokenizer.batch_decode(generated_ids, skip_special_tokens=True)[0]
        
        return response
    @property
    def _llm_type(self) -> str:
        return "Qwen2_LLM"
    

# from LLM import Qwen2_LLM
llm = Qwen2_LLM(mode_name_or_path = "/root/autodl-tmp/langchainqwen14b/model_local/qwen/Qwen1.5-7B-Chat")


# 设置RetrievalQA chain
print("=" * 10 + "设置RetrievalQA chain"  + "=" * 10)
from langchain.chains import RetrievalQA

qa = RetrievalQA.from_chain_type(
    llm=llm, 
    chain_type="stuff",
    retriever=compression_retriever_reordered,
    return_source_documents=True
)

print("=" * 10 + "查询"  + "=" * 10)
query = "what is esop?"
results = qa(query)
print(results['results'])
print(results['source_documents'])





















