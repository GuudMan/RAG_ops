from langchain_community.document_loaders import UnstructuredHTMLLoader, BSHTMLLoader

# 使用UnstructuredHTMLLoader加载HTML文件
# loader = UnstructuredHTMLLoader("/root/autodl-tmp/langchainqwen14b/ops/input_path/umac/documents/ZUF-79-19 接口/topics/1565263620985.html")
loader = UnstructuredHTMLLoader("../tmp_files/1592471936750.html")
data = loader.load()
print(data)

print("-----------------------------")
# 使用BSHTMLLoader加载HTML，提取页面标题
loader = BSHTMLLoader("../tmp_files/1592471936750.html")
data = loader.load()
print(data)
from langchain.text_splitter import RecursiveCharacterTextSplitter
text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, 
                                               chunk_overlap=200)
text_mh = text_splitter.split_documents(data)
print("==========================================")
print(text_mh)