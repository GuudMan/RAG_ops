from transformers import AutoModelForCausalLM, AutoTokenizer
from langchain.llms.base import LLM
from typing import Any, List, Mapping, Optional
from langchain.callbacks.manager import CallbackManagerForLLMRun

device = "cuda"

model_name_or_path = "../model_local/qwen/Qwen1.5-7B-Chat"
model = AutoModelForCausalLM.from_pretrained(model_name_or_path, 
                                             torch_dtype='auto', 
                                             device_map='auto')
tokenizer = AutoTokenizer.from_pretrained(model_name_or_path)

class QWen(LLM):
    max_token = 10000
    temperature = 0.01
    top_p = 0.9
    history_len = 3

    def __init__(self):
        super().__init__()
    
    @property
    def _llm_type(self):
        return "Qwen"
    
    @property
    def _history_len(self):
        return self.history_len

    def set_history_len(self, history_len = 10):
        self.history_len = history_len
    
    def _call(self, 
            prompt: str,
            stop: Optional[List[str]] = None, 
            run_manager:Optional[CallbackManagerForLLMRun] = None
    ):
        messages = [
            {'role': "system", "content":"You are a helpful assistant."},
            {'role':'user', "content":prompt}
        ]
        text = tokenizer.apply_chat_template(
            messages, 
            tokenize = False, 
            add_generation_prompt = True
        )
        model_inputs = tokenizer([text], return_tensors='pt').to(device)
        generated_ids = model.generate(model_inputs.input_ids,
                                       max_new_tokens=512)
        generated_ids = [
            output_ids[len(input_ids):] for input_ids, output_ids in zip(model_inputs.input_ids, generated_ids)
        ]
        response = tokenizer.batch_decode(generated_ids, skip_special_tokens=True)[0]
        return response

    @property
    def _identifying_params(self):
        """Get the identifying parameters"""
        return {"max_token": self.max_token, 
                "temperature": self.temperature, 
                "top_p": self.top_p, 
                "history_len": self.history_len
                }
    


    

