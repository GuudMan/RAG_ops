from langchain.llms.base import LLM
from typing import Any, List, Optional
from langchain.callbacks.manager import CallbackManagerForLLMRun
from transformers import AutoTokenizer, AutoModelForCausalLM, GenerationConfig
import torch

class DeepSeek_LLM(LLM):
    tokenizer: AutoTokenizer = None
    model: AutoModelForCausalLM = None
    
    def __init__(self, model_path):
         super().__init__()
         print("加载模型")
         self.tokenizer = AutoModelForCausalLM.from_pretrained(model_path, 
                                                               trust_remote_code=True)
         self.model = AutoModelForCausalLM.from_pretrained(model_path, 
                                                           trust_remote_code=True, 
                                                           torch_dtype=torch.bfloat16, 
                                                           divice_map='auto')
         self.model.generation_config = GenerationConfig.from_pretrained(model_path)
         self.model.generation_config.pad_token_id = self.model.generation_config.eos_token_id
         self.model = self.model.eval()

    def _call(self, prompt, stop:Optional[List[str]] = None, 
              run_manager:Optional[CallbackManagerForLLMRun] = None, 
              **kwargs:Any):
         # 重写调用函数
         messages = [
              {"role":"user", "content":prompt}
         ]
         # 构建输入
         input_tensor = self.tokenizer.apply_chat_template(messages, 
                                                           add_generation_prompt=True, 
                                                           return_tensors="pt")
         # 通过模型获得输出
         outputs = self.model.generate(input_tensor.to(self.model.device(), 
                                                       max_new_tokens=100))
         response = self.tokenizer.decode(outputs[0][input_tensor.shape[1]:], 
                                          skip_special_tokens=True)
         return response
    
    @property
    def _llm_type(self):
         return 'DeepSeek_LLM'