import os
import re
import torch
import argparse
from langchain.vectorstores import faiss
from langchain.embeddings.huggingface import HuggingFaceEmbeddings
from typing import List, Tuple
import numpy as np
from langchain.document_loaders import TextLoader
from langchain.text_splitter import CharacterTextSplitter
from langchain.docstore.document import Document
from langchain.prompts.prompt import PromptTemplate
from langchain.chains import RetrievalQA
from qwen1_5_7b_langchain_model import QWen
from qwen_txt_for_retrieval import load_file, FAISSWrapper

if __name__ == '__main__':
    # filepath = "../1571996119322.txt"
    filepath = "../ops/zedx2txt"
    # Embedding model name
    EMBEDDING_MODEL = "text2vec"
    PROMPT_TEMPLAE =  """使用以下上下文来回答最后的问题。如果你不知道答案，
    就回答不知道，不要试图编造答案。尽量使答案简明扼要。
    总是在回答的最后说“谢谢你的提问！”。上下文：{context}问题: {question} 有用的回答:"""
    # Embedding runing device
    EMBEDDING_DEVICE = "cuda"
    # return top-k text chunk from vector store
    VECTOR_SEARCH_TOP_K = 3
    CHAIN_TYPE = "stuff"
    embedding_model_dict = {
        "text2vec": "your text2vec model path"
    }
    llm = QWen()
    # embeddings = HuggingFaceEmbeddings(model_name=embedding_model_dict[EMBEDDING_MODEL], 
    #                                    model_kwargs={'device': EMBEDDING_DEVICE})
    embeddings = HuggingFaceEmbeddings(model_name="../embedding_model")
    
    docs = load_file(filepath)
    print(docs[1])
    exit(-1)
    
    docsearch = FAISSWrapper.from_documents(docs, embeddings)

    prompt = PromptTemplate(
        template=PROMPT_TEMPLAE, 
        input_variables=["content_str", "question"]
    )

    chain_type_kwargs = {"prompt":prompt, 
                         "document_variable_name":"context_str"}
    qa = RetrievalQA.from_chain_type(
        llm = llm, 
        chain_type=CHAIN_TYPE, 
        retriever = docsearch.as_retriever(search_kwargs={"k": VECTOR_SEARCH_TOP_K}),
        chain_type_kwargs=chain_type_kwargs)
    
    query = "什么是性能指标？"
    print(qa.run(query))