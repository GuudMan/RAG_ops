from langchain.llms.base import LLM
from typing import Any, List, Optional
from langchain.callbacks.manager import CallbackManagerForLLMRun
from transformers import AutoTokenizer, AutoModelForCausalLM, GenerationConfig
import torch

class MiniCPM_LLM(LLM):
    tokenizer: AutoTokenizer = None
    model: AutoModelForCausalLM = None

    def __init__(self, model_path):
        super().__init__()
        self.tokenizer = AutoTokenizer.from_pretrained(model_path, 
                                                       trust_remote_code=True)
        
        self.model = AutoModelForCausalLM.from_pretrained(model_path, 
                                                          trust_remote_code=True, 
                                                          torch_dtype=torch.bfloat16)
        self.model = self.model.eval()

minicpm = MiniCPM_LLM("")
print(minicpm)



