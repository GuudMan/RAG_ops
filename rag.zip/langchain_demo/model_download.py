import torch
from modelscope import snapshot_download, AutoModel, AutoTokenizer
import os
model_dir = snapshot_download('internlm/internlm2-chat-1_8b', 
                              cache_dir="/root/autodl-tmp/langchainqwen14b/langchain_demo/model", 
                              revision='master')
