from langchain.llms.base import LLM
from typing import Any, List, Optional
from langchain.callbacks.manager import CallbackManagerForLLMRun
from transformers import AutoTokenizer, AutoModelForCausalLM, GenerationConfig, LlamaTokenizerFast
import torch

class InternLM2_LLM(LLM):
    # 基于本地Qwen2自定义LLM 类
    tokenizer: AutoTokenizer = None
    model: AutoModelForCausalLM = None

    def __init__(self, mode_name_or_path):
        super().__init()
        print("正在从本地加载模型...")
        self.tokenizer = AutoTokenizer.from_pretrained(mode_name_or_path, 
                                                       trust_remote_code=True)
        self.model = AutoModelForCausalLM.from_pretrained(mode_name_or_path, 
                                                          torch_dtype=torch.float16, 
                                                          trust_remote_code=True)
        print("完成本地模型加载")
    
    def _call(self, prompt, stop:Optional[List[str]] = None, 
              run_manager: Optional[CallbackManagerForLLMRun] = None, 
              **kwargs:Any):
        response, history = self.model.chat(self.tokenizer, prompt, history=[])

        return response
    
    @property
    def _llm_type(self):
        return "InternLM2_LLM"
    
llm = InternLM2_LLM(mode_name_or_path="./model/internlm2-chat-7b")
llm("你是谁？")

